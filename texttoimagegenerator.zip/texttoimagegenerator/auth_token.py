import os

auth_token = os.getenv("HUGGINGFACE_AUTH_TOKEN", "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")  # Default to your token for testing

if not auth_token:
    raise EnvironmentError("HUGGINGFACE_AUTH_TOKEN environment variable is not set.")
