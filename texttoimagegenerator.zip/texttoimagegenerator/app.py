import os
import time
from flask import jsonify, Flask, request, render_template
from googletrans import Translator
from diffusers import StableDiffusionPipeline, DDIMScheduler
from PIL import Image
import torch

app = Flask(__name__)

# Configuration for the application
class CFG:
    seed = 42
    device = "cuda" if torch.cuda.is_available() else "cpu"
    generator = torch.Generator(device).manual_seed(seed)
    image_gen_steps = 5
    image_gen_model_id = "stabilityai/stable-diffusion-2"
    image_gen_size = (100, 100)
    image_gen_guidance_scale = 6

# Load the Hugging Face token from environment variables
auth_token = os.getenv("HUGGINGFACE_AUTH_TOKEN")
if not auth_token:
    raise EnvironmentError("HUGGINGFACE_AUTH_TOKEN environment variable not found.")

# Load model once at startup
print("Loading Stable Diffusion model...")
model = StableDiffusionPipeline.from_pretrained(
    CFG.image_gen_model_id,
    revision="fp16",
    use_auth_token=auth_token,
    torch_dtype=torch.float16 if CFG.device == "cuda" else torch.float32,
).to(CFG.device)
model.scheduler = DDIMScheduler.from_config(model.scheduler.config)
torch.backends.cudnn.benchmark = True
print("Model loaded successfully.")

# Translation function
def get_translation(text, dest_lang):
    translator = Translator()
    return translator.translate(text, dest=dest_lang).text

# Generate image function
def generate_image(prompt):
    return model(prompt, 
                 num_inference_steps=CFG.image_gen_steps, 
                 guidance_scale=CFG.image_gen_guidance_scale
                ).images[0]

# Save image function
def save_image(img):
    save_dir = os.path.join('static', 'images')
    os.makedirs(save_dir, exist_ok=True)
    filename = f"image_{int(time.time())}.jpg"
    save_path = os.path.join(save_dir, filename)
    img.save(save_path, format="JPEG")
    return os.path.join('images', filename)

# Routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate():
    try:
        prompt = request.form.get('prompt')
        if not prompt:
            return jsonify({'error': 'Prompt is required'}), 400
        translation = get_translation(prompt, 'en')
        img = generate_image(translation)
        save_path = save_image(img)
        return jsonify({'prompt': prompt, 'image_path': save_path})
    except Exception as e:
        print(f"Error: {str(e)}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5001)
